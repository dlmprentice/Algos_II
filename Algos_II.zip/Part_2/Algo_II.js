function printUpTo(x){
    for (var i = 1; i <= x; i++){
        console.log(i);
    }
    if (x < 0){
        console.log("negative number");
        return false;
    }

}
printUpTo(10);
printUpTo(-10);


var y = printUpTo(-10);
console.log(y);

function printSum(x){
    var sum = 0;
    for (var i = 0; i <= x; i++){
        sum += i;
        console.log(i);
           
        }
        return sum;
}



var y = printSum(255);
console.log(y);

function printSumArray(x){
    var sum = 0;
    for(var i=0; i<x.length; i++){
        sum = sum + x[i];

    }
    return sum;
}
console.log(printSumArray([1,2,3]));